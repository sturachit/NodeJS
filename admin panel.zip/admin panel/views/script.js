
//filtering in subcategory
document.addEventListener('DOMContentLoaded', () => {
    const dropdown = document.getElementById('dispsub_id');
    const burger = document.getElementById('doc');
    dropdown.addEventListener('change', () => {
        const SValue = dropdown.value;
        fetch(`/SubCatData?SValue=${SValue}`)
            .then((response) => response.json())
            .then((data) => {
                let tr = '';
                data.forEach((e) => {
                    // Assuming e.subcat_id is an object with a catname property
                    tr += `<tr>
                    <td>${e._id}</td>
                    <td>${e.subcat_id.catname}</td>
                    <td>${e.subname}</td>
                            <td><a class="btn btn-secondary" style="margin-right: 6px" href="/subEdit/${e._id}">Edit</a><a class="btn btn-danger" href="/subDelete/${e._id}">Delete</a></td>
                        </tr>`;
                });
                burger.innerHTML = tr;
            })
            .catch((error) => {
                console.log('Error:', error);
                
            });
    });

// searching in subcategory
    const searchbox = document.getElementById("search");
    searchbox.addEventListener('keyup', () => {

        const SValue = searchbox.value;
        // Send an AJAX request to the Express server
        fetch(`/filterdata?SValue=${SValue}`)
            .then((response) => response.json())
            .then((data) => {
                let tr = '';
                data.forEach((e) => {
                    tr += `<tr>
                    <td>${e._id}</td>
                    <td>${e.subcat_id.catname}</td>
                    <td>${e.subname}</td>
                    <td><a class="btn btn-secondary" style="margin-right: 6px" href="/subEdit/${e._id}">Edit</a>
                    <a class="btn btn-danger" href="/subDelete/${e._id}">Delete</a></td>
                    </tr>`;
                })
                burger.innerHTML = tr;
            })
            .catch((error) => {
                console.log('Error :', error);
            });
    });
})

//merge dropdown with category and subcategory  
const categoryDropdown = document.getElementById("subcat_id");
categoryDropdown.addEventListener('change', () => {
    const SValue = categoryDropdown.value;
    const duct = document.getElementById("procat_id")
    fetch(`/SubCatData?SValue=${SValue}`)
        .then((response) => response.json())
        .then((data) => {
            let tr = '<option>Choose SubCategory</option>';
            data.forEach((e) => {
                tr += `<option value = "${e._id}">${e.subname}</option>`;
            })
            duct.innerHTML = tr;
        })
        .catch((error) => {
            console.log('Error Generate:', error);
        });
})