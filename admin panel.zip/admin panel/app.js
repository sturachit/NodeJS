const express = require('express')  
const app = express()
const session = require('express-session')
const flash = require('connect-flash');
const cookie = require('cookie-parser')
app.use(cookie());
app.use(session({
    secret:'domination',
    // cookie: {maxAge: 3000},
    saveUninitialized: true,
    resave: true
}));
app.use(flash());
const routes = require('./routes/user')
app.use(routes)

app.use(express.static(__dirname))
app.set('view engine', 'ejs')

app.listen(9500,() => {
    console.log("calling on port 9500");    
})