const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const bodyparser = bodyParser.urlencoded({ extended: true });
const router = express.Router();
const passport = require("passport");
const cookieSession = require("cookie-session");
require("../models/googleAuth");
const roleModel = require("../models/roleModel");

// Apply body-parser globally
app.use(bodyParser.json());
app.use(bodyparser);

// Import controllers
const {
  getdashboard,
  getform,
  login,
  register,
  logout,
  forgotpass,
  getOtp,
  getFormData,
  checkUserData,
} = require("../controllers/ucontrollers");

const {
  addCategory,
  savecategory,
  updatecategory,
  deletecategory,
  editcategory,
} = require("../controllers/catControllers");

const {
  savesubCategory,
  subCategoryData,
  deleteSubcategory,
  editSubcategory,
  updateSubCategory,
  subCatData,
  FilterData,
} = require("../controllers/subControllers");

const {
  allProducts,
  saveProduct,
  dataSub,
  ProductDelete,
  editProduct,
  updateProduct
} = require("../controllers/proControllers");

const {
  saveRole,
  Role,
  checkroles,
  deleteRole,
  roleEdit,
  updateRole,
} = require("../controllers/roleControllers");

const { saveDetails, loginDetails } = require("../controllers/googleAuth");

// Routes
router.get("/admin", getdashboard);
router.get("/admin/form", getform);
router.get("/admin/login", login);
router.get("/admin/logout", logout);
router.get("/forgetpass", forgotpass);
router.post("/otp", bodyparser, getOtp);
router.get("/admin/register", register);

// Category Routes
router.get("/category", addCategory);
router.post("/saveCat", bodyparser, savecategory);
router.post("/updatecategory/:id", bodyparser, updatecategory);
router.get("/delete/:id", deletecategory);
router.get("/edit/:id", editcategory);

// Subcategory Routes
router.post("/subcategory", bodyparser, savesubCategory);
router.get("/allSubCategory", subCategoryData);
router.get("/subDelete/:id", deleteSubcategory);
router.get("/subEdit/:id", editSubcategory);
router.post("/subUpdate/:id", bodyparser, updateSubCategory);
router.get("/SubCatData", subCatData);
router.get("/filterdata", FilterData);

// Product Routes
router.post("/proCategory", bodyparser, saveProduct);
router.get("/allProducts", allProducts);
router.get("/dataSub", dataSub);
router.get("/proDelete/:id", ProductDelete);
router.get("/proEdit/:id", editProduct);
router.post("/proupdate/:id",bodyparser, updateProduct);


// Form Routes
router.post("/admin/savedata", bodyparser, getFormData);
router.post("/checklogin", bodyparser, checkUserData);

// Role Routes
router.get("/allRole", checkroles, Role);
router.post("/saveRole", bodyparser, saveRole);
router.get("/deleteRole/:id", checkroles, deleteRole);
router.get("/editrole/:id", checkroles, roleEdit);
router.post("/upadateRole/:id", bodyparser, updateRole);

// Google Auth Routes
router.get("/details", loginDetails);
router.post("/details", bodyparser, saveDetails);
router.get(
  "/auth/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);
router.get(
  "/auth/google/callback",
  passport.authenticate("google", {
    failureRedirect: "/admin/login",
  }),
  async (req, res) => {
    try {
      let roleData1 = await roleModel.find({ isActive: 1 });
      if (req.user.created) {
        res.render("logindetails", {
          user: req.user.profile,
          roleData: roleData1,
          message2: "You have been registered successfully.",
        });
      } else {
        res.redirect("/admin");
      }
    } catch (error) {
      console.error(error);
      res.status(500).send("Internal Server Error");
    }
  }
);

module.exports = router;
