const mongoose = require('mongoose');

const random = async () => {
    const url = "mongodb://127.0.0.1:27017/student";
    await mongoose.connect(url);

};  
random();
const category = new mongoose.Schema({

    id: Number,
    catname: {
        type: String,
        required: true,     
     
    },

})

const model = new mongoose.model('categorymodel', category);

module.exports = model;


