const mongoose = require('mongoose');
const  findOrCreate = require('mongoose-findorcreate')
const mainData = async ()=>{
    const url = "mongodb://127.0.0.1:27017/student"
    await mongoose.connect(url)
}
mainData()
const Data = new mongoose.Schema({
    id:Number,
    name:{
        type:String,
        required:true,
        Unique:true,
    },
    email:{
        type:String,
        required:true,
        Unique:true,
    },  
    password:String,
    otp :Number,
    token:String,
    role_id:{ type: mongoose.Schema.Types.ObjectId, ref: 'role' },
    googleId: String,
    image:String
})
Data.plugin(findOrCreate)
const studentModel = mongoose.model('adminpanel',Data)

module.exports = studentModel