const mongoose = require("mongoose");

const random = async () => {
    const url = "mongodb://127.0.0.1:27017/student";
    await mongoose.connect(url);
};

random();

const product = new mongoose.Schema({
    proname: String,
    subcat_id: { type: mongoose.Schema.Types.ObjectId, ref: 'categorymodel' },
    procat_id: { type: mongoose.Schema.Types.ObjectId, ref: 'subcategory'},
    price:Number,
    images: Array,
    Description: String
});

const proModel = new mongoose.model("Product", product);

module.exports = proModel;
