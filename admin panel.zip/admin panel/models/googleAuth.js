const passport = require("passport");
const mongoose = require("mongoose");
const uModel = require("./uModel");
var GoogleStrategy = require("passport-google-oauth20").Strategy;

passport.serializeUser((user, done) => {
  done(null, user);
});
passport.deserializeUser(function (user, done) {
  done(null, user);
});
passport.use(
  new GoogleStrategy(
    {
      clientID:
        "212076812671-rrevbjtudbs7b1g6dn5gp300gvjeed14.apps.googleusercontent.com",
      clientSecret: "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",
      callbackURL: "http://localhost:9500/auth/google/callback",
      passReqToCallback: true,
    },
    function (request, accessToken, refreshToken, profile, cb) {
      uModel.findOrCreate(  { googleId: profile.id },
        function (err, user, created) {
          if (!user) {
            // Handle the case where user is null
            return cb(err, null);
          }

          if (created) {
            user.created = true;
            user.profile = profile;
            console.log("Created ", created);
            return cb(err, user);
          } else {
            user.created = false;
            console.log('Updated "%s"', user.googleId);
            return cb(err, user);
          }
        }
      );
    }
  )
);


