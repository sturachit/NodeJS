const mongoose = require('mongoose');

const random = async () => {
    const url = "mongodb://127.0.0.1:27017/student";
    await mongoose.connect(url);

};  
random();

const subCategory = new mongoose.Schema({
    subname:String,
    subcat_id:{type :mongoose.Schema.Types.ObjectId,ref :'categorymodel'},
}) ;

const subModel = new mongoose.model('subcategory',subCategory)
module.exports = subModel;