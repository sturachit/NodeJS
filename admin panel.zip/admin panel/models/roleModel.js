const mongoose = require('mongoose');
const random = async () => {
    const url = 'mongodb://127.0.0.1:27017/student';
    await mongoose.connect(url);
};
random();

const Role = new mongoose.Schema({
    rolename: {
        type: String,
        required: true,
        unique: true
    },
    isActive:{
        type: Boolean
        
    }
}) 

const roleModel = new mongoose.model('role',Role);
module.exports = roleModel;
