const uModel = require("../models/uModel");
const express = require("express");
const app = express();
const bcrypt =require('bcrypt');
const nodemailer = require('nodemailer');
const saltRounds=10;
const  roleModel = require('../models/roleModel')
 
 const passwordHide = (password) =>{
   return bcrypt.hash(password,saltRounds);
 }  
// token generator
var jwt = require('jsonwebtoken')
const secretKey = "@2012";
 const localStorage = require('localStorage');

 //role 
//  var LocalStorage = require('node-localstorage').LocalStorage,
// localStorage = new LocalStorage('./scratch');
// const roleModel = require('../models/roleModel')

  const transporter= nodemailer.createTransport({
   port:465,
   host:"smtp.gmail.com",
   auth:{
     user:"parmarrachit5@gmail.com",
     pass:"xcojossmjespcnbq"
    },
    secure:true,
    tls: {
      rejectUnauthorized: false, // Add this line to ignore self-signed certificate errors
    },
  })

const checkUser = (req,res)=>{
  if(req.cookies && req.cookies.UserName != "Rachit"){
    return res.redirect("/admin/login")
  }
}

const getdashboard = async (req, res) => {
  await  checkUser(req, res)
  res.render('index',{username :req.cookies.UserName })
};

const getform = async (req, res) => {
  await checkUser(req, res)
  res.render('form',{username:req.cookies.UserName})
};

const login =(req,res)=>{
  res.render('login',{ message: '' })

}

const register = async(req,res)=>{
  let roleData = await roleModel.find({isActive:1});
  res.render("register",{message2 :'',roleData:roleData});
}

const logout = (req, res) => {
  localStorage.clear();
  res.clearCookie('UserName')
  res.redirect('/admin/login')
}

const getFormData = async (req, res) => {
  const {name,password,email,role_id } = req.body
  const checkUser = await uModel.findOne({email:req.body.email });
     const userRole  = await uModel.findOne({role_id}).populate('role_id')
     let roleData = await roleModel.find({isActive:1});
  
  if(req.body.email && req.body.password && req.body.name){
  if(userRole){
      if(userRole.role_id.rolename == 'Admin'){
            req.flash('success', 'Admin is already registered!');
        res.render('register', { message2: req.flash('success'),roleData:roleData });
    } else if(userRole.role_id.rolename == 'Manager'){
          const checkmanager = await uModel.find({ role_id });
          if(checkmanager.length ==2 ){
                req.flash('success', 'Two Managers already registered!');
                res.render('register', { message2: req.flash('success'),roleData:roleData });
            } else {
          const mailInfo ={
            from:"parmarrachit5@gmail.com",
            to:req.body.email,
            subject:"Admin panel",
            text:"Registration Done",
            html:"<p>registration successfully attempted.</p>"
          } ;
          const crypted = await bcrypt.hash(password, saltRounds)
          const result = new uModel({
              id: 1,
              name:name,
              email:email,
              password:crypted,
              token:'',
              role_id :role_id
            });
  
            await transporter.sendMail(mailInfo)
            await result.save();
          //jwt token
          var token =jwt.sign({result:result},secretKey)
            var _id = result._id;
            var user = await uModel.findByIdAndUpdate({_id},{$set:{token:token}})
          res.redirect("/admin/login");
        }

      } else if (checkUser) {
          req.flash("info", "Email is already Registered");
  res.render("register", { message2: req.flash("info") });
} 

}
else {
  const mailInfo ={
    from:"parmarrachit5@gmail.com",
    to:req.body.email,
    subject:"Admin panel",
    text:"Registration Done",
      html:"<p>registration successfully attempted.</p>"
    } ;
    const crypted = await bcrypt.hash(password, saltRounds)
    const result = new uModel({
      id: 1,
      name:name,
      email:email,
      password:crypted,
      token:'',
      role_id :role_id

    });
    
    await transporter.sendMail(mailInfo)
    await result.save();
    //jwt token
    var token =jwt.sign({result:result},secretKey)
    var _id = result._id;  
      var user = await uModel.findByIdAndUpdate({_id},{$set:{token:token}})
      res.redirect("/admin/login");
    }
  }
   else{
    req.flash("info", "All fields are required");
    res.render("register", { message2: req.flash("info") });
  }
    
  
};



const checkUserData = async (req, res) => {
  const checkUser = await uModel.findOne({email: req.body.email,}).populate('role_id');
    // const password = await bcrypt.compare(req.body.password,checkUser.password);

  if(req.body.email && req.body.password){
    if (checkUser) {
      res.cookie("UserName",checkUser.name)
      let rolename = checkUser.role_id.rolename;
      localStorage.setItem('userToken',JSON.stringify(checkUser.token));
      localStorage.setItem('userRole', JSON.stringify(rolename));
      res.render('index', { message: '', username: checkUser.name });
    } else {
    
      req.flash('sucess','Email or password wrong!')
      res.render('login', { message: req.flash('sucess') });
      //  res.send("Email or password not found");
    }
  }else{
    req.flash('sucess','All field need !..')
    res.render('login', { message: req.flash('sucess') });
  }
};

const forgotpass =(req,res)=>{
  res.render('forgetpass')
}

function makeOTP(){
  let min = 100000;
  let max = 999999;
  code = Math.floor(Math.random() * (max - min + 1)) + min;
  return code;
}
  
const getOtp = async (req, res) => {

  let usData = await uModel.findOne({ email: req.body.email });
  code = makeOTP();
  console.log(req.body.email);
  // console.log(code);

  if (!usData) {
      req.flash("danger", "Email is not Registered");
      res.render("register", { message3: req.flash("danger") , message2: ''});
  } else {

      const transporter = nodemailer.createTransport({
          port: 465,
          host: "smtp.gmail.com",
          auth: {
              user: "parmarrachit5@gmail.com",
              pass: "xcojossmjespcnbq",
          },
          secure: true,
          tls: {
            rejectUnauthorized: false, // Add this line to ignore self-signed certificate errors
          },
      
      });

      const mailInfo = {
          from: "parmarrachit5@gmail.com",
          to: req.body.email,
          subject: "Admin Panel",
          text: "Registration Success",
          html: `<p>Your Admin panel OTP is ${code}</p>`,
      }
      await transporter.sendMail(mailInfo);
  }
  // res.redirect('/admin/info')
};


module.exports = {
  getdashboard,
  getform,
  getFormData,
  checkUserData,
  login,
  register,
  logout,
  getOtp,
  forgotpass
  // checkLoginData
};
