const express = require('express');
const model = require('../models/catModel');
const subModel = require("../models/subcatModel");

const app = express();
app.use(express.json());
let editcat=  '';
const addCategory =async (req,res)=>{
   let catdetails = await model.find();
   res.render('category',{
    username:req.cookies.UserName,
    catdetails: catdetails,
    message3:'',
    editcat:''
})
    
}

const savecategory = async (req,res)=>{
    let catdetails = await model.find();
    let len = catdetails.length+1;
    const catname = req.body.catname;
    const cn = await  model.findOne({catname:catname});
    if(cn){
        req.flash('success', 'Category already exists');
        res.render('category',
        {
            username:req.cookies.UserName, 
            catdetails: catdetails,
            message3:req.flash('success'),
            editcat:''
        });

    }else{
        const result ={
            id: len,
            catname:catname,
        }
        const data = new model(result);
        await data.save(); 
        catdetails = await model.find();
        req.flash('success', 'Category added successfully');
        res.render('category',
        {
            username:req.cookies.UserName,
            catdetails: catdetails,
            message3:req.flash('success'),
            editcat :''
        });
    }
       
}

const deletecategory = async (req,res)=>{
    const id = req.params.id;
    const cat =await subModel.find({subcat_id:id})
    if(cat.length > 0){
        catdetails = await model.find();
        req.flash('success', 'First delete Subcategory then delete Category');
        res.render('category',{
            username:req.cookies.UserName,
            catdetails: catdetails,
            message3:req.flash('success'),
            editcat :''
         })
    }else{
  
        const Data = await model.findByIdAndRemove({_id: id});
        if(Data){
            res.redirect('/category')       
      }
    }
}

const editcategory = async (req,res)=>{
    const id = req.params.id;
    let catdetails = await model.find();
    editcat = await model.findOne({_id: id});
    if(editcat){
        res.render('category',{
            username: req.cookies.UserName,
            catdetails: catdetails,
            message3: '',
            editcat:editcat
        }); 
    }

}
const updatecategory = async (req,res)=>{
    const id = req.params.id
    const catname = req.body.catname;
    const result = await model.findByIdAndUpdate({
            _id:id
    },
        { 
            $set:{
            catname:catname
        }
    }
    )
      catdetails = await model.find();
    req.flash('success', 'Category updated successfully');
    if(result){
        res.render('category',{
            username: req.cookies.UserName,
            catdetails: catdetails,
            message3: req.flash('success'),
            editcat:''
        }); 
    }

}

module.exports = {
    addCategory,
    savecategory,
    deletecategory,
    editcategory,
    updatecategory
};