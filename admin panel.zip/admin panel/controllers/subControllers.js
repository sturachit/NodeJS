const express = require("express");
const subModel = require("../models/subcatModel");
const model = require('../models/catModel');

const app = express();
app.use(express.json());
  
const categoryData =async (req,res)=>{
    const catdetails = await  model.find();
    // console.log(catdetails);
    res.render('category',{
                    username: req.cookies.UserName,
                    catdetails: catdetails,
                    message3:'',
                    editSub:''
            });
} 

const savesubCategory = async (req,res)=>{
    let catdetails = await subModel.find();
    // let len = catdetails.length+1;
    // console.log(catdetails)
    const subname = req.body.subname;
    const id = req.body.subcat_id;
    const cn = await subModel.findOne({subname:subname});
     const result ={
            subcat_id: id,
            subname:subname,
        }
    
        const data = new subModel(result);
        await data.save(); 
         catdetails = await subModel.find();
        // res.json(catdetails);
        res.redirect('/allSubCategory')
    
}


const deleteSubcategory = async (req, res) => {
    const id =req.params.id;
    const deleteuser = await subModel.findByIdAndRemove({_id :id});
    console.log("Successfully Api deleted")
    res.redirect('/allSubCategory')
}

const editSubcategory = async(req,res) => {
    const id = req.params.id;
    let Data = await model.find();
    let dataSub =  await subModel.find().populate("subcat_id");
    result = await subModel.findOne({_id:id})
    res.render('subCategory',{
        username: req.cookies.UserName,
        catdetails: dataSub,
        message3:'',
        editSub:result,
        Data: Data
});
    
}
const updateSubCategory = async (req,res)=>{
    let catdetails = await subModel.find();
    const subname = req.body.subname;
    const id = req.body.subcat_id;
    const subid = req.params.id;
    const result = await subModel.findByIdAndUpdate({_id:subid},{
        $set:{
            subcat_id:id,
            subname:subname
        }
    })
    // console.log("Subcategory updated");       
    catdetails = await subModel.find();
        // res.json(catdetails);
        res.redirect('/allSubCategory')
}

const subCategoryData = async (req, res) => {
    let Data = await model.find()
    const dataSub = await subModel.find().populate("subcat_id") 
    console.log(dataSub);
    res.render("subCategory", {
        username: req.cookies.UserName,
        catdetails: dataSub,
        message3: '',
        editSub: '',
        Data:Data
    });
};


 const subCatData = async(req,res) => {
     let subcat_id = req.query.SValue;
    //  console.log(subcat_id);
     let dataSub;
     if(subcat_id != '') {
         dataSub =  await subModel.find({subcat_id:subcat_id}).populate("subcat_id");
        }
        else {
            dataSub =  await subModel.find().populate("subcat_id"); 
        }
            res.json(dataSub);
            console.log(dataSub);
 }


const FilterData = async (req, res) => {
    let searchtext = req.query.SValue;
    // let subData;
    const categories = await model.find({
        catname: { $regex: new RegExp(searchtext, "i") } // Case-insensitive search
    });

    // Search for subcategories where cat_id points to a matching category

    let subcategories = await subModel.find({

    // Here Category Id is found in subModel 

        subcat_id: { $in: categories.map(category => category._id) }
    }).populate("subcat_id");

    //   If we want to find subcategory than this condition works:
    if (subcategories == '') {
        subcategories = await subModel.find({ subname: { $regex: new RegExp(searchtext, "i") } }).populate("subcat_id")
    }
    res.json(subcategories);
}

module.exports = {
    savesubCategory,
    subCategoryData,
    deleteSubcategory,
    editSubcategory,
    updateSubCategory,
    subCatData,
    FilterData  
};
