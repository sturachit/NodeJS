const express = require('express');
const roleModel = require('../models/roleModel');

const app = express();
var LocalStorage = require('node-localstorage').LocalStorage,
localStorage = new LocalStorage('./scratch');

app.use(express.json());
let editrole=  '';
const Role =async (req,res)=>{
    const catdetails = await roleModel.find();
    res.render('role',{
                    username: req.cookies.UserName,
                    catdetails: catdetails,
                    message3:'',
                    editrole:editrole
            });
} 
const saveRole = async (req,res)=>{
    let catdetails = await roleModel.find();
    let len = catdetails.length+1;
    const rolename = req.body.rolename;
    const  checkRole = await roleModel.findOne({rolename:rolename})
    if(checkRole){       
            req.flash('success', 'Role already exists');
            res.render('role',{
                username: req.cookies.UserName,
                catdetails: catdetails,
                message3: req.flash('success'),
                editrole:''
            });
    } else {
        const result = {
            rolename: rolename, 
            isActive:1  
        }
        const data = new roleModel(result);
        await data.save();
        console.log(data)
        catdetails = await roleModel.find();
        req.flash('success', 'Role added successfully');
        res.render('role',{
            username: req.cookies.UserName,
            catdetails: catdetails,
            message3: req.flash('success'),
            editrole:''
        }); 
    }
    

}

const deleteRole = async (req,res)=>{
    const id = req.params.id;
    const data = await roleModel.findByIdAndRemove({_id: id});
        if(data){
            res.redirect('/allRole')
        }

}

const roleEdit = async (req,res)=>{
    const id = req.params.id;
    catdetails = await roleModel.find();
    editrole = await roleModel.findOne({_id: id});
    if(editrole){
        res.render('role',{
            username: req.cookies.UserName,
            catdetails: catdetails,
            message3: '',
            editrole:editrole
        }); 
    }

}
const updateRole = async (req,res)=>{
    const id = req.params.id
    const rolename = req.body.rolename;
    const result = await roleModel.findByIdAndUpdate({
            _id:id
    },
        {$set:{
            rolename:rolename
        }
    }
    )
    catdetails = await roleModel.find();
    req.flash('success', 'Role updated successfully');
    if(result){
        res.render('role',{
            username: req.cookies.UserName,
            catdetails: catdetails,
            message3: req.flash('success'),
            editrole:''
        }); 
    }

}

const checkroles = async(req, res,next)=>{
    let role = JSON.parse(localStorage.getItem('userRole'));
    if(role=="Admin"){
        next();
    } else {
        res.render('404')
    }

}
module.exports = {
    saveRole,Role,roleEdit,updateRole,deleteRole,checkroles
}