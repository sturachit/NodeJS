const uModel = require("../models/uModel");
const roleModel = require("../models/roleModel");
// const sendinBlue = require('sib-api-v3-sdk');
const mongoose = require("mongoose");
const nodemailer = require('nodemailer')
var LocalStorage = require("node-localstorage").LocalStorage,
  localStorage = new LocalStorage("./scratch");


const saveDetails = async (req, res) => {
  const { name, email, role_id, googleId } = req.body;
  const checkUser = await uModel.findOne({ email: req.body.email });
  const userRole = await uModel.findOne({ role_id }).populate("role_id");
  let roleData = await roleModel.find({ isActive: 1 });

  if (req.body.email && req.body.password && req.body.name) {
    if (userRole) {
      if (userRole.role_id.rolename == "Admin") {
        req.flash("success", "Admin is already registered!");
        res.render("register", {
          message2: req.flash("success"),
          roleData: roleData,
        });
      } else if (userRole.role_id.rolename == "Manager") {
        const checkmanager = await uModel.find({ role_id });
        if (checkmanager.length == 2) {
          req.flash("success", "Two Managers already registered!");
          res.render("register", {
            message2: req.flash("success"),
            roleData: roleData,
          });
        } else {
          const mailInfo = {
            from: "parmarrachit5@gmail.com",
            to: req.body.email,
            subject: "Admin panel",
            text: "Registration Done",
            html: "<p>registration successfully attempted.</p>",
          };
          email = { $regex: new RegExp(email, "i") };
          let result = await uModel.findOneAndUpdate(
            { googleId },
            {
              $set: {
                name: name,
                number: number,
                email: email,
                role_id: role_id,
              },
            }
          );

          await transporter.sendMail(mailInfo);
          await result.save();
          var token = jwt.sign({ result: result }, secretkey);
          console.log("generated token");
          console.log(token);
          var _id = result._id;
          console.log(_id);
          var user = await uModel.findByIdAndUpdate(
            { _id },
            { $set: { token: token } }
          );

          localStorage.setItem("userRole", JSON.stringify(rolename));
          res.redirect("/admin/login");
        }
      } else if (checkUser) {
        req.flash("info", "Email is already Registered");
        res.render("register", { message2: req.flash("info") });
      }
    } else {
      const mailInfo = {
        from: "parmarrachit5@gmail.com",
        to: req.body.email,
        subject: "Admin panel",
        text: "Registration Done",
        html: "<p>registration successfully attempted.</p>",
      };
      // const crypted = await bcrypt.hash(password, saltRounds)
      let result = await model.findOneAndUpdate(
        { googleId },
        {
          $set: {
            name: name,
            number: number,
            email: email,
            role_id: role_id,
          },
        }
      );

      await transporter.sendMail(mailInfo);
      await result.save();
      res.redirect("/admin/login");
    }
  } else {
    req.flash("info", "All fields are required");
    res.render("register", { message2: req.flash("info") });
  }
};

const loginDetails = (req, res) => {
  res.render("loginDetails", {});
};

module.exports = { loginDetails, saveDetails };
