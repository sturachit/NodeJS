const express = require("express");
const subModel = require("../models/subcatModel");
const model = require('../models/catModel');
const proModel = require('../models/productModel');
const app = express();
const bodyParser = require('body-parser');
app.use(bodyParser.json());
const fs = require('fs');

const allProducts = async (req, res) => {
    try {
        const catdetails = await model.find();
        const productData = await proModel.find().populate("subcat_id").populate("procat_id");
        res.render('product', {
            username: req.cookies.UserName,
            Data: catdetails,
            message3: '',
            catdetails: productData,
            editPro:'',
            roleData:[]

        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

const dataSub = async (req, res) => {
    try {
        const catid = req.query.SValue;
        const data = await subModel.find({ subcat_id: catid });
        if (data) {
            res.json(data);
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

const saveProduct = async (req, res, next) => {
    try {
        const path = '../images/' + Date.now() + '.png';
        const imgdata = req.body.image;
        if (!imgdata) {
            throw new Error('Invalid image data: Image data is empty or not provided');
        }
        // Convert base64 format into random filename
        const base64Data = imgdata.replace(/^data:([A-Za-z-+/]+);base64,/, '');
        fs.writeFileSync(path, base64Data, { encoding: 'base64' });
        const result = {
            subcat_id: req.body.subcat_id,
            procat_id: req.body.procat_id,
            price: req.body.price,
            proname: req.body.proname,
            editProduct: '',
            images: [base64Data]
        };
        const data = new proModel(result);
        await data.save();
        res.redirect('/allProducts');
    } catch (err) {
        console.error(err);
        res.status(400).send(err.message); // Send descriptive error message to client
    }
};


const ProductDelete = async (req, res) => {
    const id =req.params.id;
    const deleteuser = await proModel.findByIdAndRemove({_id :id});
    console.log("Successfully Api deleted")
    res.redirect('/allProducts')
}

const editProduct = async(req,res) => {
    const id = req.params.id;
    const catdetails = await model.find();
    const productData = await proModel.find().populate("subcat_id").populate("procat_id");
    result = await proModel.findOne({_id:id})
    res.render('Product', {
        username: req.cookies.UserName,
        Data: catdetails,
        message3: '',
        catdetails: productData,
        editPro:result
        // roleData:[]

    });
    
}
const updateProduct = async (req,res)=>{
    let catdetails = await proModel.find();
    const proname = req.body.proname;
    const id = req.body.procat_id;
    const proid = req.params.id;
    const result = await proModel.findByIdAndUpdate({_id:proid},{
        $set:{
            procat_id:id,
            proname:proname
        }
    })      
    catdetails = await proModel.find();
        // res.json(catdetails);
        res.redirect('/allProducts')
}

module.exports = {
    allProducts,
    saveProduct,
    dataSub,
    ProductDelete,
    editProduct,
    updateProduct
};
